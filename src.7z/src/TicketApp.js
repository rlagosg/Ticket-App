import React from 'react'
import { RouterPages } from './pages/RouterPages'
import { UiProvider } from './context/UiContext'

export const TicketApp = () => {
  return (    
    <UiProvider>
      <RouterPages />
     </UiProvider>     
  )
}
